class PositiveNumber{
	public static void main (String args[]){
		int n = 9;
		if(n>0){
			System.out.println("number is positive");
		}else{
			System.out.println("number is Negative");

		}
	}
}
