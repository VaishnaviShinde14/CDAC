class GoodMorning{
	public static void main (String args[]){
		int n = 9;
		if(n >= 6 && n <= 12){
			System.out.println("Good Morning");
		}
	}
}