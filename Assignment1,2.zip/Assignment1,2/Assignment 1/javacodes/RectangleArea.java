class RectangleArea{
	public static void main (String args[]){
		int len = 9;
		int wid = 10;
		
			System.out.println("Area of Rectangle is :"+ len*wid);
		
	}
}