class EvenOdd{
	public static void main (String args[]){
		int n = 9;
		if(n%2==0){
			System.out.println("number is Even");
		}else{
			System.out.println("number is Odd");

		}
	}
}