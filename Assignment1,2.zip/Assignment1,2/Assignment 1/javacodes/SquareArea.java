class SquareArea{
	public static void main (String args[]){
		int n = 9;
		
			System.out.println("Area of square is :"+ n*n);
		
	}
}