class Q2 {
    public static void main(String[] args) {
        int day = 4;
        switch(day) {
            case 1:
                System.out.print("Monday");
                System.out.print("WeekDay");
                break;
            case 2:
                System.out.print("Tuesday");
                System.out.print("WeekDay");
                break;
            case 3:
                System.out.print("Wednesday");
                System.out.print("WeekDay");
                break;
            case 4:
                System.out.print("Thursday");
                System.out.print("WeekDay");
                break;
            case 5:
                System.out.print("Friday");
                System.out.print("WeekDay");
                break;
            case 6:
                System.out.print("Saturday");
                System.out.print("Weekend");
                break;
            case 7:
                System.out.print("Sunday");
                System.out.print("Weekend");
                break;
            default:
                System.out.print("invalid input");
                break;
        }
    }
}
