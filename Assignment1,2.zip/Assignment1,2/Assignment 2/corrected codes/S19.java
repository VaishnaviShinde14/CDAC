/*

public class Main { 
 public static void main(String[] args) { 
 int a = 10; 
 int b = 0; 
 int result = a / b; 
 System.out.println(result); 
 } 
} 

Error : this will thow ArithmeticException because  division by zero is undefined in mathematics, and Java adheres to this rule.

*/
public class S19 { 
 public static void main(String[] args) { 
 int a = 10; 
 int b = 1; 
 int result = a / b; 
 System.out.println(result); 
 } 
} 
