/*
Snippet 9: 
public class Main { 
 public static void main(String[] args) { 
	 int class = 10; 
	 System.out.println(class); 
 } 
} 

Error : class is a keyword in java which is used to create class. we cant use this as a variable 
*/
//corrected
public class S9 { 
 public static void main(String[] args) { 
 int classs = 10; 
	System.out.println(classs); 
 } 
} 