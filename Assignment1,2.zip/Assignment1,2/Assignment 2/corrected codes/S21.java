/*
Snippet 21: 
public class Main { 
 public static void main(String[] args) { 
 System.out.println("Hello, World!"); 
 // Missing closing brace here 
} 

*/

// corrected 
public class Main { 
 public static void main(String[] args) { 
 System.out.println("Hello, World!"); 
 }
} 
