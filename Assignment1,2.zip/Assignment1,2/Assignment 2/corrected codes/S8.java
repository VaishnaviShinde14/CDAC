/*
snippet 8 :
public class Main { 
 public static void main(String[] args) { 
 System.out.println("Hello, World!" 
 } 
} 

Error: there is a syntax error we have to close the bracket and put the semicolon.

*/

//corrected

public class S8 { 
 public static void main(String[] args) { 
	System.out.println("Hello, World!"); 
 } 
} 