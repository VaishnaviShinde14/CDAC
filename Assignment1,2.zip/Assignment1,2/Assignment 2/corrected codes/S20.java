/*
Snippet 20: 
public class Main { 
 public static void main(String[] args) { 
 System.out.println("Hello, World") 
 } 
} 
Error : Syntax error occured. because semicolon is missing in line 3. semicolon is important as it indicates where the statement ends
*/ 
public class S20 { 
 public static void main(String[] args) { 
 System.out.println("Hello, World");
 } 
} 
