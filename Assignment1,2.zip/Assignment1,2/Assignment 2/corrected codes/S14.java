/*
Snippet 14: 
public class Main { 
 public static void main(String[] args) { 
 double num = "Hello"; 
 System.out.println(num); 
 } 
} 
Error : we are trying to to put a string value to double datatype variable which is not accepted. we need to change the type of variable;

*/

public class S14 { 
 public static void main(String[] args) { 
 String num = "Hello"; 
 System.out.println(num); 
 } 
} 
