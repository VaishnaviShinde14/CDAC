/*
Snippet 16:
public class Main { 
 public static void main(String[] args) { 
 int num = 10; 
 double result = num / 4; 
 System.out.println(result); 
 } 
} 

*/

public class S16 { 
 public static void main(String[] args) { 
	 int num = 10; 
	 double result = num / 4f; 
	 System.out.println(result); 
 } 
} 
