
const TAX_RATE = 0.10; 
let cart = [];
// Function to add item to cart
function addItem(itemName, price) {
    const item = { name: itemName, price: price };
    cart.push(item);
    calculateTotal();
}
// Function to calculate total with tax
function calculateTotal() {
    let total = 0;
    for (let item of cart) {
        //total += item.price;
        total = item.price;
    }
    total += total * TAX_RATE;
    console.log(`Total (with tax): RS ${total.toFixed(2)}`);
}

addItem("Book", 150);
addItem("Pen", 10.00);
addItem("phone",33000)


