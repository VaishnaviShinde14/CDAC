const names1 = ["Rahul", "Rohit"];
const names2 = ["Virat", "Rishabh"];
const allnames = [...names1, ...names2];
console.log(allnames); 