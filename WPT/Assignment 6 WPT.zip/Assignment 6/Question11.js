function RS(callback, delay) {
    setTimeout(callback, delay);
}

RS(() => console.log("hello after delay!"), 1000);
