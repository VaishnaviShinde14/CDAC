const numbers = [10, 20, 30, 40, 50];
const [first, second] = numbers;
console.log(first, second);
