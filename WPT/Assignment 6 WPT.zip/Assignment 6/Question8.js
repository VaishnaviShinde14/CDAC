const cartItems = [{ price: 10 }, { price: 20 }, { price: 30 }];
const totalPrice = cartItems.reduce((total, item) => total + item.price, 0);
console.log(totalPrice); 
