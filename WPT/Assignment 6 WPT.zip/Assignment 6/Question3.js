const book = {
    title: "The Hitman: The Rohit Sharma Story",
    author: "Vijay Lokapally and G. Krishnan",
    yearPublished: 2020,
    
    displayDetails(){
        console.log(`Title: ${this.title}`);
        console.log(`Author: ${this.author}`);
        console.log(`Year Published: ${this.yearPublished}`);

    }

};
book.displayDetails();