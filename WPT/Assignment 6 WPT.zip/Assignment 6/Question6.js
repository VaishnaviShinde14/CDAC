const names = ["Rohit", "Rahul", "Siddheshwar", "Baburao"];
const lengths = names.map(name => name.length);
console.log(lengths); 
