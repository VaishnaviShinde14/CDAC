const car = {
    make: "Rolls-Royce",
    model: "Phantom",
    year: 2023,
    color: "Black"
};

const { make, model, year, color } = car;

console.log(make, model, year, color); 
