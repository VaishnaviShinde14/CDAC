// Regular Function
function areaOfRectangle(length, width) {
    return length * width;
}
// Arrow Function
const areaOfRectangleArrow = (length, width) => length * width;

console.log(areaOfRectangle(5, 10));       
console.log(areaOfRectangleArrow(5, 10));  
