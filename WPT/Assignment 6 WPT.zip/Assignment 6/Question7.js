const numbersArray = [1, 2, 3, 4, 5, 6];
const evens = numbersArray.filter(num => num % 2 === 0);
console.log(evens); 
