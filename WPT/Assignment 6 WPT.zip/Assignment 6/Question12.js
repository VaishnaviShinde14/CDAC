const delayedPromise = new Promise((resolve) => {
    setTimeout(() => resolve("Hello world"), 3000);
});

delayedPromise.then(message => console.log(message));
